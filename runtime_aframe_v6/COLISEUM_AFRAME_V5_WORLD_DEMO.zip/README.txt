THE COLISEUM — A-FRAME CDN WORLD DEMO (V5)
What you will SEE:
- Compliance popup (first run) -> Accept
- Member gate (invite code) -> Enter
- Then a circular lobby + demo pit + spectator rail
- A demo poker table pod with 6 bots that auto-play hands (flop/turn/river + pot)
- Watch OS icons bottom-right, live ticker at bottom
- Mobile joystick (left-bottom) for walking on Android

Invite code default: 1234
Admin bypass (testing only): 57130420

NOTE:
This is a visual + gameplay demo loop (offline). It does NOT connect to real sports APIs yet.
You can replace the ticker and jumbotron text logic inside js/app.js.
